//note: here we use Vue.js to connect to the paystack API for payment tranactions:
new Vue({
	el:;//"#email"


	//data components are referenced using this..
	data:{
		//get data from user from the UI:
		
		//username:
		//passHash:
		//email:
		//CardNumber:
		//AccNum:
		//BVN:
		//VerIDimg:
		//isSalaried:
		//auto_PayTime://Hourly,Daily,Weekly, Monthly
		//lock://True or false
		//invest:
		
	}

	//manipulates the data components:
	methods:{

		//confirm user
		confirmUser: function(){
			//confirm user info based on the BVN using Paystack API..
		}

		payToBusinessAcc: function(){
			if(confirmUser()){
				//invoke the paystack handler..
				var payHandler = PaystackPop.setup({
      				key: ,//payment public key generated in business' paystack account
      				email: //email from UI data,
      				amount: //amount from UI data,
      				currency: //currency default:"NGN",
      				//ref: // generates a custom pseudo-unique reference.paystack API will generate one for me..
      				metadata: {
        				custom_fields: [
            				{
            					//the fields I want to appear associated with getting the card details...
                				display_name: "Mobile Number",
                				variable_name: "mobile_number",
                				value: "+2348012345678"
            				}
         				]
      				},

      				callback: function(response){
      					//use the onsenUI and w3css for display..
      					//use phonegap for native vibrate functionalities 
          				alert('success. transaction ref is ' + response.reference);
      				},

      				onClose: function(){
      					//use the onsenUI and w3css for display..
      					//use phonegap for native vibrate functionalities..
          				alert('window closed');
      				}
      			});
      			//fire the paystack operation..
    			payHandler.openIframe();
    		}else{
    			//use the onsenUI and w3css for display..
      			//use phonegap for native vibrate functionalities..
      			alert('Unfortunately, your identity could not be confirmed. Please try to fill up again');
    		}
		}

		payBacktoCustomersAcc: function(){


		}


		//AjoToken:
		AjoToken: function(){
			//use subscription API from Paystack...
			switch(auto_PayTime){

				case "Daily":
					//use daily auto-subscribe model.. 
				break

				case "Weekly":
					//use the weekly auto-subscribe model..
				break

				case "Monthly":
					//use the monthly auto-sucbscribe model
				break

				default:
					payToBusinessAcc();
			}
		}

		//AjoLock:
		AjoLock: function(){
			if(lock){
				let CurrentDate = getCurrentDate();//return type 
				let DateOfUnlock = getDateOfUnlock();//return type 

				let timeDifference = DateOfUnlock - CurrentDate;
				for(let i=0; i<=timeDifference; timeDifference--){

					//use the onsenUI and w3css for display..
      				//use phonegap for native notification functionalities.. 
					ShowCountdown(timeDifference--);
					if(timeDifference-- === 0){
						//Unlock For Withdrawal into the User's Account...
						if(autoWithdraw){
							payBacktoCustomersAcc();
							//use the onsenUI and w3css for display...
      						//use phonegap for native vibrate and notification functionalities...
      						alert("Great! Your locked away money has been unlocked and automatically deposited into your account");
						}else{
							//use the onsenUI and w3css for display...
							//use phonegap for native vibrate and notification functionalities...
							switch(prompt("Great! Your locked away money has been unlocked. Do you wish to withdraw it immediately?")){
								case "Yes":
									payBacktoCustomersAcc();
								break

								case "No":
									//use the onsenUI and w3css for display...
									//use phonegap for native vibrate and notification functionalities...
								break
							}
						}
					}
				}
			}
		}


		//AjoVest:
		AjoVest: function(){
			while(invest){

				if(ForThreeMonths){
					//investment lock for 3 months
					let originalAmount = this.amount;
					let interestRate = 0.05 * originalAmount;   

					let finalWithdrawValue = originalAmount + interestRate;
					

				}else if(ForTwelveMonths){
					//investment lock for Twelve months
					let originalAmount = this.amount;
					let interestRate = 0.2 * originalAmount;
					let finalWithdrawValue = originalAmount + interestRate;
				}	
			}
		}

	}

	
	//dependants:
	computed:{

	}
});
