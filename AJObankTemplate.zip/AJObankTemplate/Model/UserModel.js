class UserModel{

	constructor(){

		var username = this.username;
		var passHash = this.passHash;
		var email = this.email;
		var PhoneNumber = this.PhoneNumber;
		var CardNumber = this.CardNumber;
		var AccNum = this.AccNum;
		var BVN = this.BVN;
		var VerIDimg = this.VerIDimg;//of type byte(ie image)load directly from user input. 
		var isSalaried = this.isSalaried;//of boolean type..
	}

	//Begin to use PouchDB to persist...
	//define CRUD:
	Create(){
		//create user database using PouchDB
		var UserDb = new PouchDB('User');

		//create a document:
		var doc = {
			"_id":"uniqueUser",
			"username":this.username,
			"password" : this.passHash, 
			"email" : this.email,
			"Phone_Number":this.PhoneNumber,
			"Card_Number":this.CardNumber,
			"Account_Number":this.AccNum,
			"BVN":this.BVN,
			/*"VerIDimg":this.VerIDimg*///This is an image/blob - special
			_attachments:{
      			'VerIDimg': {
        			//type: this.VerIDimg.type,
        			data: this.VerIDimg//store inside the database directly...
				}
			}

			"isSalaried": this.isSalaried
		}


		//Put it inside database: 
		UserDb.put(doc);
		//return UserDb;
		//handle error accordingly
	}

	Read(){
		//Read all stored data
		if(UserDb){
			//get a promise:
			UserDb.get('uniqueUser', {attachments: true}).then(function(doc){
				//return the results:
				this.username = doc.username;
				this.passHash = doc.password;
				this.email = doc.email;
				this.phoneNumber = doc.Phone_Number;
				this.CardNumber = doc.CardNumber;
				this.AccNum = doc.Account_Number;
				this.BVN = doc.BVN;
				//this.VerIDimg = doc.VerIDimg;
				this.isSalaried = doc.isSalaried;

				return this.username;
				return this.passHash;
				return this.email;
				return this.phoneNumber;
				return this.CardNumber;
				return this.AccNum;
				return this.BVN;
				return this.VerIDimg;//as an image
				return this.isSalaried;
			})//handle error accordingly...
		}/*else{
			Create();
		}*/
	}
	

	Update(){
		//change the result in the database:
		UserDb.get('uniqueUser', {attachments: true}).then(function(doc){
			doc.username = this.username;
			doc.passHash = this.passHash;
			doc.email = this.email;
			doc.phoneNumber = this.phoneNumber;
			doc.CardNumber = this.CardNumber;
			doc.Account_Number = this.Account_Number;
			doc.BVN = this.BVN;
			doc.VerIDimg = this.VerIDimg;//update as an image.
			doc.isSalaried = this.isSalaried;
		})
	}

	Delete(){
		//based on user option to delete their records and start fresh:
		 UserDb.get('uniqueUser').then(function(doc){
		 	return UserDb.remove(doc);
		 })
		 //handle error as appropriate here..

	}

}