//optional use of let keyword..
class UserMoneyModel {

	/*This only monitors the state not perform the processes:
	The processes are handled by the VueJS layer*/
	constructor(){
		//initial settings:
		var autoCredit = this.autoCredit;//of type boolean
		var autoCreditDate = this.autoCreditDate;//Vue must process this before saving 
		var autoCreditTime = this.autoCreditTime;//Vue must process this before saving

		var autoDebit = this.autoDebit;//of type boolean
		var autoDebitDate = this.autoDebitDate;//Vue must process this before saving
		var autoDebitTime = this.autoDebitTime;//Vue must process this before saving

		var setReminder = this.setReminder;//of type Boolean 

		//State after money is moved into the app from the user account: 
		var UserAmtDebited = this.UserAmtDebited;
		var AppAmtCredited = this.AppAmtCredited;

		//State after money is moved out of the app back into the user's account:
		var UserAmtCredited = this.UserAmtCredited;
		var AppAmtDebited = this.AppAmtDebited; 


		//for AjoToken:
		//setReminder
		var Contrib = this.Contrib; //contribute daily, weekly or monthly(do it manually or autowithdraw)
		//autoCredit:true or false
		//autoDebit:true or false
		var ContribDate = this.ContribDate;
		var ContribTime = this.ContribTime;
		//setReminder
		/*To put into the app*/
		//UserAmtDebited
		//AppAmtCredited
		/*To withdraw back into user's account*/
		//UserAmtCredited
		//AppAmountDebited
		//setReminder


		//for AjoLock:
		/*To put into the app*/
		//setReminder 
		//UserAmtDebited
		//AppAmtCredited
		//autoCredit:true or false
		//autoDebit:true or false
		var Locked = this.Locked;//of type Boolean
		var LockedDurationDate = this.LockedDurationDate;//Vue must process this before saving 
		var LockedDurationTime = this.LockDurationTime;//Vue must process this before saving 
		//setReminder 
		/*To withdraw back into user's account*/
		//UserAmtCredited
		//AppAmountDebited
		//setReminder


		//for AjoVest:
		/*To put into the app*/	
		//setReminder
		//UserAmtDebited
		//AppAmtCredited
		//autoCredit:true or false
		//autoDebit:true or false
		var invest = this.invest;//of type boolean
		var interestRate = this.interestRate;
		/*Optional:*/
		//Locked
		//LockedDurationDate
		//LockedDurationTime
		//setReminder 
		/*To withdraw back into user's account*/
		//UserAmtCredited
		//AppAmountDebited
		//setReminder
	}



		//Begin use PouchDB to persist... 
		//define CRUD:
		Create(){
			//use PouchDB to persist data:
			var UserMoneyDb = new PouchDB(User);

			var doc = {
				"_id":"uniqueUserMoney"
				"autoCredit":this.autoCredit;
				"autoCreditDate":this.autoCreditDate;
				"autoCreditTime":this.autoCreditTime;

				"autoDebit":this.autoDebit;
				"autoDebitDate":this.autoDebitDate;
				"autoDebitTime":this.autoDebitTime;

				 "setReminder":this.setReminder;

				 "UserAmtDebited":this.UserAmtDebited;
				 "AppAmtCredited":this.AppAmtCredited;

				 "UserAmtCredited":this.UserAmtCredited;
				 "AppAmtDebited":this.AppAmtDebited;

				 "Contrib":this.Conrib;

				 "ContribDate":this.ContribDate;
				 "ContribTime":this.ContribTime;

				  "Locked":this.Locked;
				  "LockedDurationDate":this.LockedDurationDate;
				  "LockedDurationTime":this.LockedDurationTime;

				  "invest":this.invest;
				  "interestRate":this.interestRate
			}
			UserMoneyDb.put(doc);
				//return UserMoneyDb..
				//handle error accordingly.
		}			

			/*test:
			if(this.autoDebit == true){
				console.log("I have to withdraw from your account now because. You set autoDebit to true");
			}*/

		Read(){
			if(UserMoneyDb){
				UserMoneyDb.get('uniqueUserMoney').then(function(doc){
					this.autoCredit = doc.autocredit;
					this.autoCreditDate = doc.autoCreditDate;
					this.autoCreditTime = doc.autoCreditTime;

					this.autoDebit = doc.autoDebit;
					this.autoDebitDate = doc.autoDebitDate;
					this.autoDebitTime = doc.autoDebitTime;

					this.setReminder = doc.setReminder; 

					this.UserAmtDebited = doc.UserAmtDebited;
					this.AppAmtCredited = doc.AppAmtCredited;

					this.UserAmtCredited = doc.UserAmtCredited;
					this.AppAmtDebited = doc.AppAmtDebited;

					this.Contrib = doc.Contrib;

					this.ContribDate = doc.ContribDate;
					this.ContribTime = doc.ContribTime;

					this.Locked = doc.Locked;
					this.LockedDurationDate = doc.LockedDurationDate;
					this.LockedDurationTime = doc.LockedDurationTime;

					this.invest = doc.invest;
					this.interestRate = doc.interestRate;
				}) //handle error here...
			}	
		}

		Update(){
			if(UserMoneyDb){
				UserMoneyDb.get('uniqueUserMoney').then(function(doc){
					doc.autoCredit = this.autoCredit;
					doc.autoCreditDate = this.autoCreditDate;
					doc.autoCreditTime = this.autoCreditTime;

					doc.autoDebit = this.autoDebit;
					doc.autoDebitDate = this.autoDebitDate;
					doc.autoDebitTime = this.autoDebitTime;

					doc.setReminder = this.setReminder;

					doc.UserAmtDebited = this.UserAmtDebited;
					doc.AppAmtCredited = this.AppAmtCredited;

					doc.UserAmtCredited = this.UserAmtCredited;
					doc.AppAmtDebited = this.AppAmtDebited;

					doc.Contrib = this.Contrib;

					doc.ContribDate = this.ContribDate;
					doc.ContribTime = this.ContribTime;

					doc.Locked = this.Locked;
					doc.LockedDurationDate = this.LockedDurationDate;
					doc.LockedDurationTime = this.LockedDurationTime;

					doc.invest = this.invest;
					doc.interestRate = this.interestRate;
				})//handle error here
			}
		}


		Delete(){
			UserMoneyDb.get('uniqueUser').then(function(doc){
		 		return UserMoneyDb.remove(doc);
		 	})
		}
}

let MoneyModel = new UserMoneyModel();
MoneyModel.autoDebit = true;
MoneyModel.Create();





