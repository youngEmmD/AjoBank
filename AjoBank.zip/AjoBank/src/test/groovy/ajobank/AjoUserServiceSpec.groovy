package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoUserServiceSpec extends Specification implements ServiceUnitTest<AjoUserService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
