package ajobank

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AjoUserLocationSpec extends Specification implements DomainUnitTest<AjoUserLocation> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
