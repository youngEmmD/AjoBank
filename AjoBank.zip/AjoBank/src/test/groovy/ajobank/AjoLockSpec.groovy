package ajobank

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AjoLockSpec extends Specification implements DomainUnitTest<AjoLock> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
