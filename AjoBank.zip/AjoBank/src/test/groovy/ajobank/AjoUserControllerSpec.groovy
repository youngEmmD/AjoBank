package ajobank

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AjoUserControllerSpec extends Specification implements ControllerUnitTest<AjoUserController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
