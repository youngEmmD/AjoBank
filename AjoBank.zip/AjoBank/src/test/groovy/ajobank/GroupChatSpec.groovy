package ajobank

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class GroupChatSpec extends Specification implements DomainUnitTest<AjoGroupChat> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
