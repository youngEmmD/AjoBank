package ajobank

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AjoVestControllerSpec extends Specification implements ControllerUnitTest<AjoVestController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
