package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoTokenServiceSpec extends Specification implements ServiceUnitTest<AjoTokenService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
