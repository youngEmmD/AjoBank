package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoMonitorServiceSpec extends Specification implements ServiceUnitTest<AjoMonitorService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
