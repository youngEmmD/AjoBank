package ajobank

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AjoGroupWalletActivityControllerSpec extends Specification implements ControllerUnitTest<AjoGroupWalletActivityController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
