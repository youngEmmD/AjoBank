package ajobank

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AjoTokenControllerSpec extends Specification implements ControllerUnitTest<AjoTokenController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
