package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoGroupWalletActivityServiceSpec extends Specification implements ServiceUnitTest<AjoGroupWalletActivityService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
