package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoLockServiceSpec extends Specification implements ServiceUnitTest<AjoLockService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
