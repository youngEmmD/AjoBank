package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoUserWalletActivityServiceSpec extends Specification implements ServiceUnitTest<AjoUserWalletActivityService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
