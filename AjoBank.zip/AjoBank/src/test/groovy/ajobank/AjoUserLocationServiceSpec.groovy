package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoUserLocationServiceSpec extends Specification implements ServiceUnitTest<AjoUserLocationService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
