package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoGroupChatServiceSpec extends Specification implements ServiceUnitTest<AjoGroupChatService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
