package ajobank

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AjoGroupSpec extends Specification implements DomainUnitTest<AjoGroup> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
