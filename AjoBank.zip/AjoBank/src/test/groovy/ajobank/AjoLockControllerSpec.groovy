package ajobank

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AjoLockControllerSpec extends Specification implements ControllerUnitTest<AjoLockController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
