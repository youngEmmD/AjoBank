package ajobank

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AjoTokenSpec extends Specification implements DomainUnitTest<AjoToken> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
