package ajobank

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AjoVestServiceSpec extends Specification implements ServiceUnitTest<AjoVestService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
