package ajobank

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AjoMonitorSpec extends Specification implements DomainUnitTest<AjoMonitor> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
