package ajobank

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AjoGroupWalletControllerSpec extends Specification implements ControllerUnitTest<AjoGroupWalletController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
