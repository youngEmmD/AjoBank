package ajobank

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
