package ajobank

class AjoMonitor {

    /**this model monitors the domain classes for suggestions and intuitive resolution such as:
        * When a group needs more people to contribute
        * Money locked away might be put to better use in Contribution or Investing
        * Time is approaching for a user to contribute, withdraw from group's wallet into the user wallet...
        * Reminder when time approaches to contribute(personally) or get money as appropriate
     */

    //fetch:
    AjoUser ajouser
    AjoGroup ajogroup

    static constraints = {

        ajouser(nullable:true, unique:true)
        ajogroup(nullable:true, unique:true)

    }

    static mappings = {

        ajouser(lazy:false)
        ajogroup(lazy:false)
    }

}
