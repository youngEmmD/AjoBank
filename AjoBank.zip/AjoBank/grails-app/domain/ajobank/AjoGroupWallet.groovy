package ajobank

class AjoGroupWallet {

    transient ModelUtilityService modelUtilityService
    //HasA:
    AjoGroupWalletActivity grpWalletActivity

    //BelongsTo:
    static belongsTo = [AjoGroup]

    def GroupNumber //UUID

    def GroupAmountPaid
    def AmountAvailable
    def WithdrawStatus//available for withdrawal or not..

    static constraints = {
        GroupNumber(unique:true, nullable:false)
        GroupAmountPaid(nullable:true)
        AmountAvailable(nullable:true)
        WithdrawStatus(nullable:true, inlist:["Available", "Not-Available"])
        grpWalletActivity(nullable:false)
    }

    static mappings={
        //grpWalletActivity(lazy: false)
    }
}
