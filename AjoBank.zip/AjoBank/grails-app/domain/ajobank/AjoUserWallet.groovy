package ajobank

//get ModelUtilityService method UUIDGenerate()

class AjoUserWallet {
    transient ModelUtilityService modelUtilityService

    //HasA:
    AjoUserWalletActivity userWalletActivity

    //BelongsTo:
    static belongsTo = [AjoUser]

    def UserWalletUUID = modelUtilityService.UUIDGenerate()
    def AccountName
    def AccountNumber
    def CardNumber

    boolean Automode //Automatically debit and credit user's wallet

    static constraints = {
        AccountName(blank:false, unique:true)
        AccountNumber(blank:false, unique:true)
        CardNumber(blank:false, creditCard:true, unique:true)
        userWalletActivity(nullable:false, unique:true)
    }

    static mappings = {
        userWalletActivity(lazy:false)
    }
}
