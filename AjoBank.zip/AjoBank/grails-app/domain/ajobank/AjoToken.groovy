package ajobank

class AjoToken {

    //BelongsTo:
    static belongsTo = [AjoUserWallet]

    //HasA:
    AjoLock ajolock //User can lock away token

    def dailyToken
    def weeklyToken
    def MonthlyToken

    //About each transaction history
    def TransHistory
    Date EachTokenDate
    def EachTokenTime

    //General info:
    Date dateCreated
    Date withdrawDate
    def AmountContributed //so far

    //optional:
    def autoDebitPeriod //Period to make contributions automatically
    def autoCreditPeriod //Period to withdraw automatically

    static constraints = {

        ajolock(nullable:true)

        dailyToken(nullable:true)
        weeklyToken(nullable:true)
        monthlyToken(nullable:true)

        TransHistory(unique:true, nullable:true)
        EachTokenDate(nullable:true)
        EachTokenTime(nullable:true)

        dateCreated(nullable:true, validator{
            //ensure the date created is not less than the present date:
            if (it?.compareTo(new Date()) < 0 ) {
                return false
            }
            return true
        })

        withdrawDate(nullable:true, validator{ val, obj ->
            //ensure the expected date is not less than the date Created:
            if (val != null) {
                return val.after(obj.dateCreated)
            }
            return true
        })

        AmountContributed(nullable:true)
        autoDebitPeriod(nullable:true)
        autoCreditPeriod(nullable:true)
    }

    static mappings = {
        //lazy fetching:
        ajolock(lazy:true)
    }
}
