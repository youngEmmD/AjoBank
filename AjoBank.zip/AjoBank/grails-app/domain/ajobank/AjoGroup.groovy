package ajobank

class AjoGroup {

    //HasMany, belongsTo:
    static hasMany = [ajousers: AjoUser]
    static belongsTo = [ajousers: AjoUser]

    //HasA:
    AjoGroupWallet GroupWallet
    AjoGroupChat GroupChat


    def GroupAgeRange//User in this group has to be within certain age range

    def GroupOccupationType//User in this group has to be either salaried or non-salaried...

    Date dateCreated //Date the Group was created..

    //User in this group has to be within certain circular location radius:
    def GroupLocationRange

    //User in this group has to pay this amount periodically for contribution:
    final def SetAmount

    //There is a set net duration for each group..during this time, there will be intervals for disbursement for each person in the group
    def NetDuration

    static constraints = {
    }

    static mappings ={
    }
}
