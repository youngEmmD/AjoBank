package ajobank

class AjoVest {

    //belongsTo:
    static belongsTo = [AjoUserWallet]

    //HasA:
    AjoLock ajolock //User can lock away investment

    def investChoice //3 months or six months
    def investAmount
    def investPeriod

    Date dateCreated
    Date expectedCreditDate
    def expectedAmount

    static constraints = {

        ajolock(nullable:true)

        investChoice(inList:[3, 6])
        investAmount(nullable:false)
        dateCreated(nullable:false, validator{
            //ensure the date created is not less than the present date:
            if (it?.compareTo(new Date()) < 0 ) {
                return false
            }
            return true
        })

        expectedCreditDate(nullable:false, validator{ val, obj ->
            //ensure the expected date is not less than the date Created:
            if (val != null) {
                return val.after(obj.dateCreated)
            }
            return true
        })

        expectedAmount(nullable:false)

        investPeriod(nullable:true)
    }

    static mappings = {
        //ajoLock will utilize lazy fetching..
        ajolock(lazy:true)
    }
}
