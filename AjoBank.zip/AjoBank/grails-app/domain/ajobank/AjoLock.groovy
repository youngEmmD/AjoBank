package ajobank

class AjoLock {

    //belongsTo:
    static belongsTo = [AjoUserWallet, AjoToken, AjoVest]

    def LockStartDate
    def LockDuration
    boolean AutoDebitBeforeLockBegins
    boolean AutoCreditWhenLockExpires
    def LockedAmount

    boolean AutoLock
    boolean shouldLockToken
    boolean shouldLockVest

    static constraints = {
    }

    static mappings = {
    }
}
