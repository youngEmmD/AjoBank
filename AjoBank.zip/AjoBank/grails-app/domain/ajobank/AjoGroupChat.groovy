package ajobank

class AjoGroupChat {

    def sendChat
    def receiveWordChat

    byte[] sendPicture
    byte [] receivePicture

    transient boolean isSent
    transient boolean isReceive

    static belongsTo = [AjoGroup]

    static constraints = {
    }

    static mappings = {
    }
}
