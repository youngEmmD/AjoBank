package ajobank

class AjoGroupWalletActivity {

    boolean availableForChat
    def DisburseTime//for the next random person in the GroupQueue/GroupStack to receive funds

    /**As each user in the group will be collecting money after
        the interval agreed upon by the group e.g monthly..
    */

    //Our algorithm selects the next person from the queue at random in other not to be biased..
    Random RandomUserChooser

    Queue <AjoGroup> GroupQueue
    Stack<AjoGroup> GroupStack

    static constraints = {
    }
}
