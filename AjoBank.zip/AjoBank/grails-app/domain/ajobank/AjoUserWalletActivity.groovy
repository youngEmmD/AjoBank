package ajobank

class AjoUserWalletActivity {

    def CurrentBalance
    def lastGroupDepositMade

    //each user can:
    AjoToken ajoToken //Daily, weekly or monthly token contributions -> HasA..
    AjoLock ajoLock //Lock your money away inside your wallet for a specified period of time -> HasA..
    AjoVest ajoVest //Lock Invest for a few months and earn income apart from the initial investment -> HasA..


    static belongsTo = [ajouserwallet: AjoUserWallet]

    static constraints = {
        CurrentBalance(nullable:false)
        lastGroupDepositMade(nullable:false )
        ajoToken(nullable:false, unique:true)
        ajoLock(nullable:false, unique:true)
        ajoVest(nullable:false, unique:true)
    }

    static mappings = {

        ajoToken(lazy:false)
        ajoLock(lazy:false)
        ajoVest(lazy:false)
    }
}
