package ajobank

//get ModelUtilityService method PasswordHash()

class AjoUser {

    //import utilityService(Not to be saved inside a database):
    transient ModelUtilityService modelUtilityService

    //HasA:
    AjoUserLocation userlocation

    //HasA
    AjoUserWallet AjoWallet

    //HasMany, belongsTo:
    static hasMany = [ajogroups: AjoGroup]
    static belongsTo = [AjoGroup]

    //HasA:
    AjoUserLocation userLocation

    //defines db details for the AjoUser:
    def UserName
    def HashedPassword = modelUtilityService.PasswordHash()//convert user provided password to hashed
    def PhoneNumber
    def UserEmail
    def BVN //check if we can confirm user's BVN on PayStack
    byte[] UserImage

    //collect proper information:
    def UserAge
    def UserOccupationType //Either salaried or non-salaried
    boolean isAnonymous

    static constraints = {
        //note: password mustn't be equal to UserName..
        UserName(size:8..15, blank:false, unique:true)
        HashedPassword(blank:false, unique:true)
        PhoneNumber(blank:false, unique:true)
        UserEmail(email:true, blank:false, unique:true)
        BVN(blank:false, unique:true)
        UserImage(nullable:true)

        UserAge(size:18..100)
        UserOccupationType(inList:["Salaried", "Non-Salaried"])

        userLocation(nullable:false)
        AjoWallet(nullable:false, unique:true)
    }

    static mappings = {

        //loads with AjoBank..
        AjoWallet (lazy:false)
        userlocation(lazy:false)
    }
}
