package ajobank

class AjoUserLocation {

    //BelongsTo:
    static belongsTo = [AjoUser]

    def UserCountry
    def UserState
    def UserCity

    def UserAddress

    def UserLongitude //Use user's phone GPS to get this..
    def UserLatitude //->

    static constraints = {
    }

    static mappings = {
    }
}
