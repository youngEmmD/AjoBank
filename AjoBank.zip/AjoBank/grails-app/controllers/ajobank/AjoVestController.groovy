package ajobank

class AjoVestController {

    static responseFormats = ['json'] //for now, we use only JSON.

    AjoVestService ajoVestService

    def index() {
        //respond AjoVest.Query_or_Crud_here
    }
}
