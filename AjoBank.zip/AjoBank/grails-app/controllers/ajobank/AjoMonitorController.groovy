package ajobank

class AjoMonitorController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoMonitorService ajoMonitor

    def index() {
        //respond AjoMonitor.Query_or_Crud_here
    }
}
