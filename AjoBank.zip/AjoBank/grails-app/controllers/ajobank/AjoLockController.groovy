package ajobank

class AjoLockController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoLockService ajoLockService
    def index() {
        //respond AjoLock.Query_or_Crud_here
    }
}
