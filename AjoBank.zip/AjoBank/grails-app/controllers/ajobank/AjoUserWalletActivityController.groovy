package ajobank

class AjoUserWalletActivityController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoUserWalletActivityService ajoUserWalletActivityService

    def index() {
        //respond AjoUserWalletActivity.Query_or_Crud_here
    }
}
