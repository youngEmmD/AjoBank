package ajobank

class AjoUserController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoUser ajoUser

    def index() {
        //respond AjoUser.Query_or_Crud_here

    }
}
