package ajobank

class AjoTokenController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoTokenService ajoTokenService
    def index() {
        //respond AjoToken.Query_or_Crud_here
    }
}
