package ajobank

class UrlMappings {

    static mappings = {
        //This is the default grails URL mapping...will use the RESTFUL style in this project
        "/$controller/$action?/$id?(.$format)?"{
            constraints {
                // apply constraints here
            }
        }

        //These are the defaults for WEB view mappings://but we aren't using this..
        "/"(view:"/index")
        "500"(view:'/error')
        "404"(view:'/notFound')
    }
}
