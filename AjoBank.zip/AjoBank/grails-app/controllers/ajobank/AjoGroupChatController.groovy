package ajobank

class AjoGroupChatController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoGroupChatService ajoGroupChatService

    def index() {
        //respond AjoGroupChat.Query_or_Crud_here
    }
}
