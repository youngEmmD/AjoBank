package ajobank

class AjoGroupWalletController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoGroupWalletService  ajoGroupWalletService

    def index() {
        //respond AjoGroupWallet.Query_or_Crud_here
    }
}
