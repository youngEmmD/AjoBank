package ajobank

class AjoUserLocationController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoUserLocationService ajoUserLocationService

    def index() {
        //respond AjoUserLocation.Query_or_Crud_here
    }
}
