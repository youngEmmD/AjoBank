package ajobank

class AjoUserWalletController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoUserWalletService ajoUserWallet

    def index() {
        //respond AjoUserWallet.Query_or_Crud_here
    }
}
