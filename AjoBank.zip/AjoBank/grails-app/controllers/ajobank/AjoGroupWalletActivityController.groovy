package ajobank

class AjoGroupWalletActivityController {

    static responseFormats = ['json']//for now, we use only JSON.

    AjoGroupWalletActivityService ajoGroupWalletActivityService

    def index() {
        //respond AjoGroupWalletActivity.Query_or_Crud_here
    }
}
