package ajobank

class AjoGroupController {

        static responseFormats = ['json']//for now, we use only JSON.

        AjoGroupService ajoGroupService

        def index() {
            //respond AjoGroup.Query_or_Crud_here
        }
}
