package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoGroupChatService {
    //get the CRUD
    //get the CRUD:
    def CreateAjoGroupChat(){}
    def ReadAjoGroupChat(){}
    def UpdateGroupChat(){}
    def DeleteAjoGroupChat(){}
}
