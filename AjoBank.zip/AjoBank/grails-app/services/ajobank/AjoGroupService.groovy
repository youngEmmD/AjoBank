package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoGroupService {

    //get the CRUD:
    def CreateAjoGroup(){}
    def ReadAjoGroup(){}
    def UpdateAjoGroup(){}
    def DeleteAjoGroup(){}
}
