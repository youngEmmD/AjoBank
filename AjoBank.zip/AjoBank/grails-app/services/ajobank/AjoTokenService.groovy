package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoTokenService {
    //get the CRUD
    //get the CRUD:
    def CreateAjoToken(){}
    def ReadAjoUserToken(){}
    def UpdateAjoToken(){}
    def DeleteAjoTOken(){}
}
