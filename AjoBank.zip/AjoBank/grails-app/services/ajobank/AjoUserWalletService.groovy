package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoUserWalletService {

    //get the CRUD:
    def CreateAjoUserWallet(){}
    def ReadAjoUserWallet(){}
    def UpdateAjoUserWallet(){}
    def DeleteAjoUserWallet(){}
}
