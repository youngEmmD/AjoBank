package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoUserLocationService {

    def serviceMethod() {

    }
}
