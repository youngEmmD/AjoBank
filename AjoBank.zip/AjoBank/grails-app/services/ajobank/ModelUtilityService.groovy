package ajobank

import grails.gorm.transactions.Transactional
import java.security.*

@Transactional
class ModelUtilityService {

    def PasswordHash = { userPassword ->
        //encodeAsSHA256Bytes()
        byte [] passByte = (String)userPassword.getByte()

        MessageDigest PasswordHash = MessageDigest.getInstance("SHA256")
        PasswordHash.update(passByte)
        PasswordHash.digest()

        return PasswordHash
    }

    def UUIDGenerate = { PasswordHash ->

        def PassString = PasswordHash.toString()
        UUID uniqueUser = UUID.fromString(PassString)

        return uniqueUser
    }.memoize()//for speed
}
