package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoLockService {

    def CreateAjoLock(){}
    def ReadAjoLock(){}
    def UpdateAjoLock(){}
    def DeleteAjoLock(){}
}
