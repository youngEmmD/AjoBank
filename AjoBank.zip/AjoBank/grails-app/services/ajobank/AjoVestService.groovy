package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoVestService {

    //get the CRUD:
    def CreateAjoVest(){}
    def ReadAjoVest(){}
    def UpdateAjoVest(){}
    def DeleteAjoVest(){}

}
