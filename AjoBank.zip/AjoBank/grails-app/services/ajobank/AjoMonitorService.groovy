package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoMonitorService {

    //get the CRUD:
    def CreateAjoMitor(){}
    def ReadAjoMonitor(){}
    def UpdateAjoMonitor(){}
    def DeleteAjoMonitor(){}
}
