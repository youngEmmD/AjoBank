package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoUserService {

    //get the CRUD:
    def CreateAjoUser(){}
    def ReadAjoUser(){}
    def UpdateAjoUser(){}
    def DeleteAjoUser(){}
}
