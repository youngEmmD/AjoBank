package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoGroupWalletService {

    //get CRUD
    def CreateAjoGroupWallet(){}
    def ReadAjoGroupWallet(){}
    def UpdateAjoGroupWallet(){}
    def DeleteAjoGroupWallet(){}
}
