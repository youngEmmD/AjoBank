package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoUserWalletActivityService {

    //get the CRUD
    //get the CRUD:
    def CreateAjoUserWalletActivity(){}
    def ReadAjoUserWalletActivity(){}
    def UpdateAjoUserWalletActivity(){}
    def DeleteAjoUserWalletActivity(){}
}
