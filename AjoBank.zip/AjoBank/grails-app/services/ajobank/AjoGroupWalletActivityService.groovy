package ajobank

import grails.gorm.transactions.Transactional

@Transactional
class AjoGroupWalletActivityService {
    //get the CRUD:
    def CreateAjoGroupWalletActivity(){}
    def ReadAjoGroupWalletActivity(){}
    def UpdateAjoGroupWalletActivity(){}
    def DeleteAjoGroupWalletActivity(){}
}
