import 'package:ajobank/appTheme.dart';
import 'package:ajobank/UserStuffs/UserProfile.dart';
import 'package:ajobank/customDrawer/drawerUserController.dart';
import 'package:ajobank/customDrawer/homeDrawer.dart';
import 'package:ajobank/feedbackScreen.dart';
import 'package:ajobank/helpScreen.dart';
import 'package:ajobank/inviteFriendScreen.dart';
import 'package:flutter/material.dart';

//This is a stateful app...
class NavigationHomeScreen extends StatefulWidget {
  @override
  _NavigationHomeScreenState createState() => _NavigationHomeScreenState();
}

class _NavigationHomeScreenState extends State<NavigationHomeScreen> {
  Widget screenView;
  DrawerIndex drawerIndex;
  AnimationController sliderAnimationController;

  @override
  void initState() {
    drawerIndex = DrawerIndex.HOME;
    screenView =
        UserProfile(); //This should display user's User Profile Page...
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.nearlyWhite,
      child: SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
          backgroundColor: AppTheme.nearlyWhite,
          body: DrawerUserController(
            screenIndex: drawerIndex,
            drawerWidth: MediaQuery.of(context).size.width * 0.75,
            animationController: (AnimationController animationController) {
              sliderAnimationController = animationController;
            },
            onDrawerCall: (DrawerIndex drawerIndexdata) {
              changeIndex(drawerIndexdata);
            },
            screenView: screenView,
          ),
        ),
      ),
    );
  }

  void changeIndex(DrawerIndex drawerIndexdata) {
    if (drawerIndex != drawerIndexdata) {
      drawerIndex = drawerIndexdata;
      if (drawerIndex == DrawerIndex.HOME) {
        setState(() {
          screenView = UserProfile(); //display the main view..
        });
      } else if (drawerIndex == DrawerIndex.Help) {
        setState(() {
          screenView = HelpScreen();
        });
      } else if (drawerIndex == DrawerIndex.FeedBack) {
        setState(() {
          screenView = FeedbackScreen();
        });
      } else if (drawerIndex == DrawerIndex.Invite) {
        setState(() {
          screenView = InviteFriend();
        });
      } else if (drawerIndex == DrawerIndex.Share) {
        setState(() {
          //screenView = RateApp();
        });
      } else if (drawerIndex == DrawerIndex.About) {
        setState(() {
          //screenView = AboutUs();
        });
      }
    }
  }
}
