import 'package:ajobank/appTheme.dart';
import 'package:ajobank/navigationHomeScreen.dart';
import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  //Build Context Widget here:
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(children: CoolList(context)),
      ),
    );
  }

  CoolList(BuildContext context) {
    Username();
    Password();
    LoginBtn(context);
    SignUp(context);
    //checkout range expression in dart...
  }

  //Widget for Username here, this will extend Stateful later on:
  Widget Username() {
    Commons("Username");
  }

  //Widget for Password here, this will extend Stateful later on:
  Widget Password() {
    Commons("Password");
  }

  //Widget for Login button here:
  Widget LoginBtn(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 16, left: 32, right: 32),
      child: Padding(
        //child:Decorations(),
        child: RaisedButton(
            child: Text('Login',
                style: TextStyle(
                  fontFamily: AppTheme.fontName,
                  fontSize: 16,
                  color: AppTheme.dark_grey,
                )),
            onPressed: () {
              //confirm user when pressed in future version:
              Navigator.push(
                  context, //goto home screen after this:
                  MaterialPageRoute(
                      builder: (context) => NavigationHomeScreen()));
            }),
      ),
    );
  }

  //Widget for signUp:
  Widget SignUp(BuildContext context) {
    return SizedBox(
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Divider(
        height: 1,
        color: AppTheme.grey.withOpacity(0.6),
      ),
      Column(
        children: <Widget>[
          ListTile(
            title: new Text(
              "Not Registered? SignUp Now ->",
              style: new TextStyle(
                fontFamily: AppTheme.fontName,
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color: AppTheme.darkText,
              ),
              textAlign: TextAlign.left,
            ),
            trailing: new Icon(
              Icons.add_to_home_screen, //change this icon when in IDE
              color: Colors.green,
            ),
            onTap: () {
              //goto the Registeration Page
              /*Navigator.push(
                							context,
                							MaterialPageRoute(builder:(context) => RegisterPage())
                						),*/
            },
          ),
          SizedBox(
            height: MediaQuery.of(context).padding.bottom,
          ),
        ],
      )
    ]));
  }

  //common component
  Widget Commons(String EntityName) {
    return Padding(
      padding: EdgeInsets.only(top: 16, left: 32, right: 32),

      //child:Decorations();

      child: new ClipRRect(
        borderRadius: new BorderRadius.circular(25),
        child: Container(
          padding: EdgeInsets.all(4.0),
          constraints: BoxConstraints(minHeight: 80, maxHeight: 160),
          color: AppTheme.white,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(left: 10, right: 10, top: 0, bottom: 0),
            child: TextField(
              maxLines: null,
              onChanged: (String txt) {},
              style: TextStyle(
                fontFamily: AppTheme.fontName,
                fontSize: 16,
                color: AppTheme.dark_grey,
              ),
              cursorColor: Colors.blue,
              decoration: new InputDecoration(
                  border: InputBorder.none, hintText: "$EntityName"),
            ),
          ),
        ),
      ),
    );
  }

  //Common Decoration:
  Widget Decorations() {
    return Container(
      decoration: new BoxDecoration(
        color: AppTheme.white,
        borderRadius: new BorderRadius.circular(8),
        boxShadow: <BoxShadow>[
          BoxShadow(
              color: Colors.grey.withOpacity(0.8),
              offset: Offset(4, 4),
              blurRadius: 8),
        ],
      ),
    );
  }
}
