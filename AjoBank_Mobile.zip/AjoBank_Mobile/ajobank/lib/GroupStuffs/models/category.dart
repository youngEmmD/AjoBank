import 'dart:core';

class Category {
  String imagePath;
  String title;
  var lessonCount;
  var Needed;
  var Found;
  var Remaining;
  var money;
  double rating;
  var timeCreated;
  var selectionTimeLeft;

  //default constructor:
  Category({
    this.imagePath = '',
    this.title = '',
    this.lessonCount = 0,
    this.Needed = 0,
    this.Remaining = 0,
    this.Found = 0,
    this.money = 0,
    this.rating = 0.0,
    this.timeCreated = '',
    this.selectionTimeLeft = 0,
  });

  //referencing a list in dart language:
  static List<Category> categoryList = [
    //categoryList[0]
    Category(
      imagePath: 'assets/design_course/interFace1.png',
      title: 'YoungEmmy created a group @ 15m away from you',
      lessonCount: 50, //replace as #50k in the UI
      Needed: 10,
      Found: 7,
      Remaining: 3,
      money: 500, //replace as #500k in the UI
      rating: 9.0,
      timeCreated: '4/10/2015 @ 8:15am',
      selectionTimeLeft: selectionCountDown(2000),
    ),

    //categoryList[1]
    Category(
      imagePath: 'assets/design_course/interFace2.png',
      title: 'DalvikMoney created a group @ 90m away from you',
      lessonCount: 20,
      Needed: 5,
      Found: 2,
      Remaining: 3,
      money: 100,
      rating: 9.5,
    ),

    //categoryList[2]
    Category(
      imagePath: 'assets/design_course/interFace1.png',
      title: 'CoolDude4 created a group @ 40m away from you',
      lessonCount: 70,
      Needed: 11,
      Found: 5,
      Remaining: 6,
      money: 770,
      rating: 9.6,
    ),

    //categoryList[3]
    Category(
      imagePath: 'assets/design_course/interFace2.png',
      title: 'You have just created a group now',
      lessonCount: 40,
      Needed: 5,
      Found: 1,
      Remaining: 4,
      money: 200,
      rating: 0.0,
    ),
  ];

  /*static List<Category> popularCourseList = [
    Category(
      imagePath: 'assets/design_course/interFace3.png',
      title: 'App Design Course',
      lessonCount: 12,
      money: 25,
      rating: 4.8,
    ),
    Category(
      imagePath: 'assets/design_course/interFace4.png',
      title: 'Web Design Course',
      lessonCount: 28,
      money: 208,
      rating: 4.9,
    ),
    Category(
      imagePath: 'assets/design_course/interFace3.png',
      title: 'App Design Course',
      lessonCount: 12,
      money: 25,
      rating: 4.8,
    ),
    Category(
      imagePath: 'assets/design_course/interFace4.png',
      title: 'Web Design Course',
      lessonCount: 28,
      money: 208,
      rating: 4.9,
    ),
  ];*/

  static selectionCountDown(int timeChunk) {
    //set up a time chunk for demo purpose: ->This will be set by the creator of the group:
    var timeChunk;
    for (timeChunk; timeChunk >= 0; timeChunk--) {
      //display counter:
      timeChunk = timeChunk--;
      return timeChunk;
    }
  }

  static final String ajoGroupPhil =
      '''The AjoGroup contribution is safe, secured and 
  					                            removes the redundancy of middle-men to raise 
  					                            funds for personal and SME development.''';
}
